# Login-Analyzer (Streamlit)

## Cách chạy
1. Tạo môi trường ảo và cài đặt:
```
python -m venv venv
source venv/bin/activate  # hoặc venv\Scripts\activate trên Windows
pip install -r requirements.txt
```
2. Chạy ứng dụng:
```
streamlit run app.py
```
3. Upload file log (hoặc dùng sample_logs/sample_auth.log)
